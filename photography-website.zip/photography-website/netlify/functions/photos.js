// netlify/functions/photos.js

exports.handler = async (event) => {
    const CLOUD_NAME = process.env.CLOUDINARY_CLOUD_NAME;
    const API_KEY    = process.env.CLOUDINARY_API_KEY;
    const API_SECRET = process.env.CLOUDINARY_API_SECRET;

    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Content-Type': 'application/json'
    };

    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 204, headers, body: '' };
    }

    if (!CLOUD_NAME || !API_KEY || !API_SECRET) {
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Missing environment variables',
                debug: { hasCloudName: !!CLOUD_NAME, hasApiKey: !!API_KEY, hasApiSecret: !!API_SECRET }
            })
        };
    }

    const folder = event.queryStringParameters?.folder;
    if (!folder) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing folder parameter' }) };
    }

    try {
        const url = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/resources/by_asset_folder`
                  + `?asset_folder=${encodeURIComponent(folder)}&max_results=500`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64')
            }
        });

        const text = await response.text();
        let data = {};
        try { data = JSON.parse(text); } catch(e) {}

        // Always return full debug info so we can diagnose
        const publicIds = (data.resources || [])
            .sort((a, b) => a.public_id.localeCompare(b.public_id))
            .map(r => r.public_id);

        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                photos: publicIds,
                debug: {
                    status: response.status,
                    url,
                    folder,
                    resourceCount: (data.resources || []).length,
                    rawResponse: text.substring(0, 1000)
                }
            })
        };

    } catch (err) {
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: err.message, stack: err.stack })
        };
    }
};
